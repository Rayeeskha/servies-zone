<x-backend.css />
<x-backend.topbar />
<x-backend.sidebar />

<!-- Page Container START -->
<div class="page-wrapper">
    {{ $slot }}
</div>


<x-backend.js />
