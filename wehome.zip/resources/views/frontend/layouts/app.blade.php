@include('frontend.layouts.include.css')
@include('frontend.layouts.include.header')

@section('container')
			 
 	<!-- Page Wrapper -->
@show 



@include('frontend.layouts.include.footer')
@include('frontend.layouts.include.js')

@include('frontend.layouts.include.modal')