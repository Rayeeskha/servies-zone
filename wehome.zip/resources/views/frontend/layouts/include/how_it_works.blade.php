<!--How it works Section Satrt-->
<section id="howitwork">
  <div class="container text-center">
    <h1 class="panel-heading">How it works</h1>
    <div class="row">
      <div class="col-md-3 col-xs-offset-0 step-one"> <img  src="{{ asset('frontend/images/Book.png') }}" alt="Book" class="img-circle htw" />
        <h4>Book</h4>
        <p>Select the date and time like<br />
          your perofessional to show up</p>
      </div>
      <div class="col-md-1 hidden-xs hidden-sm"> </div>
      <div class="col-md-3 step-two"> <img  src="{{ asset('frontend/images/Schedule.png') }}" alt="Schedule" class="img-circle" />
        <h4>Schedule</h4>
        <p>Certified Taskers comes over<br/>
          and done your task</p>
      </div>
      <div class="col-md-1 hidden-xs hidden-sm"> </div>
      <div class="col-md-3"> <img  src="{{ asset('frontend/images/Relax.png') }}" alt="Relax" class="img-circle" />
        <h4>Relax</h4>
        <p>your task is completed to your<br/>
          satisfaction - guranteed</p>
      </div>
    </div>
  </div>
</section>
<!--How it works Section End--> 