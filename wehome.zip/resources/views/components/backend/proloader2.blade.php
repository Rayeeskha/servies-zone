<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
    <div class="formPreloader2" style="display: none;">
	 	<img src="{{ asset('backend/assets/preloader/loader.gif') }}" style="height: 100px; width: auto;">
	</div>

</div>