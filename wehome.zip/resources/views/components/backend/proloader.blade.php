<div class="formPreloader" style="display: none;">
 	<img src="{{ asset('backend/assets/preloader/loader2.gif') }}" style="height: 100px; width: auto;">
</div>