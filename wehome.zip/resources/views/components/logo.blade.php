<a href="/">
    <img src="{{ asset('backend/assets/images/logo/wehome_lg.png') }}" class="w-30 h-30 fill-current text-gray-500">
</a>