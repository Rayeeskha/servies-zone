<div>
    <!--Service Provider Satrt-->
	<section id="service_provider">
	<div class="container text-center">
	  <h1 class="panel-heading">Worldwide largest home service provider</h1>
	  <div class="row">
	    <div class="col-md-12"> 
	      <!--counter box-->
	      <div class="counter_box">
	        <div class="counter_number_right">
	          <div class="counter_number counter"><span class="stat-count">20000</span>+</div>
	          <h4 class="counter_name">HAPPY CUSTOMERS</h4>
	        </div>
	      </div>
	      <!--counter box end--> 
	      <!--counter box-->
	      <div class="counter_box">
	        <div class="counter_number_right">
	          <div class="counter_number counter"><span class="stat-count">10000</span>+</div>
	          <h4 class="counter_name">SERVICE PROVIDERS</h4>
	        </div>
	      </div>
	      <!--counter box end--> 
	    </div>
	  </div>
	</div>
	</section>
	<!--/Service Provider Satrt End--> 
</div><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/components/frontend/world-service-provider.blade.php ENDPATH**/ ?>