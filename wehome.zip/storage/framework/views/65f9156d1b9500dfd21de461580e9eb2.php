<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
    <div class="formPreloader2" style="display: none;">
	 	<img src="<?php echo e(asset('backend/assets/preloader/loader.gif')); ?>" style="height: 100px; width: auto;">
	</div>

</div><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/components/backend/proloader2.blade.php ENDPATH**/ ?>