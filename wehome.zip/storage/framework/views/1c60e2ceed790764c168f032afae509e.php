<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="content">
   <div class="page-header">
      <div class="page-title">
         <h4>Edit Role & Permissions</h4>
      </div>
      <div class="page-btn">
         <a class="btn btn-added" href="<?php echo e(route('admin.role-master.index')); ?>"><span class="fa fa-share"></span>&nbsp;&nbsp;All Role & Permissions</a>
      </div>
   </div>
   <form action="<?php echo e(route('admin.role-master.store')); ?>"  method="post" enctype="multipart/form-data" class="submitForm">
   <input type="hidden" name="id" value="<?php echo e(@$roleMaster->id); ?>">      
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-3 col-sm-12">
               <div class="form-group">
                  <label>Role</label>
                  <input type="text" name="role_name" value="<?php echo e(@$roleMaster->name); ?>">
                  <span class="text-danger Errrole_name"></span>
               </div>
            </div>
            <div class="col-lg-9 col-sm-12">
               <div class="form-group">
                  <label>Role Description</label>
                  <input type="text" name="role_description" value="<?php echo e(@$roleMaster->description); ?>">
               </div>
            </div>
            <div class="col-12 mb-3">
               <div class="input-checkset">
                  <ul>
                     <li>
                        <label class="inputcheck">Select All
                        <input type="checkbox" id="select-all">
                        <span class="checkmark"></span>
                        </label>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
            <div class="row">
               <div class="col-12">
                  <div class="productdetails product-respon">
                     <ul>
                        <?php if(isset($modules[0])): ?>
                           <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php 
                                 $checked = ''; $add = ''; $edit = ''; $delete = ''; $view=''; $status='';
                                 if ( ($key1 = array_search($modu->module_id, array_column($previllage, 'module_id') ) ) !== false ) {  
                                    $checked = 'checked';
                                    $add = @($previllage[$key1]['add_per']) ? 'checked' : ''; 
                                    $edit = @($previllage[$key1]['edit_per']) ? 'checked' : ''; 
                                    $view = @($previllage[$key1]['view_per']) ? 'checked' : '';
                                    $status = @($previllage[$key1]['status_per']) ? 'checked' : ''; 
                                    $delete = @($previllage[$key1]['delete_per']) ? 'checked' : ''; 
                                 }
                              ?>
                              <li>                           
                                 <h4 class="mb-1">
                                    <label>
                                    <input type="checkbox" value="<?php echo e($modu->module_id); ?>" id="<?php echo e($modu->module_id); ?>" name="module_id[]" onchange="onClickHandlerModule('<?php echo e($modu->module_id); ?>')" <?php echo e($checked); ?> />
                                    <span><b><?php echo e($modu->name); ?>&nbsp;List</b></span>
                                    </label>
                                 </h4>                              
                                 <div class="input-checkset">
                                    <ul>
                                       <li>
                                          <label class="inputcheck">Create
                                          <input type="checkbox" name="<?php echo e($modu->module_id); ?>_add"  onchange="onClickHandler('<?php echo e($modu->module_id); ?>_add')" id="<?php echo e($modu->module_id); ?>_add" <?php echo e(@$add); ?>>
                                          <span class="checkmark"></span>
                                          </label>
                                       </li>
                                       
                                       <li>
                                          <label class="inputcheck">Edit
                                          <input type="checkbox" name="<?php echo e($modu->module_id); ?>_edit"  onchange="onClickHandler('<?php echo e($modu->module_id); ?>_edit')" id="<?php echo e($modu->module_id); ?>_edit" <?php echo e(@$edit); ?>>
                                          <span class="checkmark"></span>
                                          </label>
                                       </li>
                                       <li>
                                          <label class="inputcheck">Change Status
                                          <input type="checkbox" name="<?php echo e($modu->module_id); ?>_status"  onchange="onClickHandler('<?php echo e($modu->module_id); ?>_status')" id="<?php echo e($modu->module_id); ?>_status" <?php echo e($status); ?>>
                                          <span class="checkmark"></span>
                                          </label>
                                       </li>
                                       <li>
                                          <label class="inputcheck">View
                                          <input type="checkbox" name="<?php echo e($modu->module_id); ?>_view"  onchange="onClickHandler('<?php echo e($modu->module_id); ?>_view')" id="<?php echo e($modu->module_id); ?>_view" <?php echo e($view); ?>>
                                          <span class="checkmark"></span>
                                          </label>
                                       </li>
                                       <li>
                                          <label class="inputcheck">Delete
                                          <input type="checkbox" name="<?php echo e($modu->module_id); ?>_delete"  onchange="onClickHandler('<?php echo e($modu->module_id); ?>_delete')" id="<?php echo e($modu->module_id); ?>_delete" <?php echo e(@$delete); ?>>
                                          <span class="checkmark"></span>
                                          </label>
                                       </li>                                
                                    </ul>
                                 </div>
                              </li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                     </ul>
                  </div>
               </div>
            </div>
            </br> <br>
            <div class="col-lg-12">
               <?php if (isset($component)) { $__componentOriginal96198cdcbb817f0c0551bcabb1f17369 = $component; } ?>
<?php $component = App\View\Components\Backend\Proloader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.proloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Proloader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369)): ?>
<?php $component = $__componentOriginal96198cdcbb817f0c0551bcabb1f17369; ?>
<?php unset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369); ?>
<?php endif; ?>
               <a href="<?php echo e(route('admin.role-master.index')); ?>" class="btn btn-cancel">Cancel</a>
               <button type="submit" class="btn btn-submit me-2"><span class="fa fa-plus"></span>&nbsp;&nbsp;Add Permission</button>
            </div>
         </div>
      </div>
   </form>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>


<?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/admin/role_master/edit.blade.php ENDPATH**/ ?>