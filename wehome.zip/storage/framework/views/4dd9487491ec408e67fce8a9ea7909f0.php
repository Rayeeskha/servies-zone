<form class="validateForm" action="<?php echo e(route('inquiry.book_service')); ?>" enctype="multipart/form-data" method="post" >
   <?php echo csrf_field(); ?>
   <input type="hidden" name="country_id" value="1">
   <div class="modal-body">
      <div class="row">
         <div class="col-md-12">
            <label>Service</label>
            <select name="lead_service_id" class="form-control">
               <option value="" selected="" disabled="">Select Service</option>
               <?php $__currentLoopData = CustomHelper::getBookingLeadService() ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e(@$val->id); ?>" <?php echo e(@$serviceId == @$val->id ? 'selected' : ''); ?>><?php echo e(@$val->service_name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <span class="text-danger Errlead_service_id"></span>
         </div>
         <div class="col-md-6">
            <label>Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Name">

            <span class="text-danger Errname"></span>
         </div>
         <div class="col-md-6">
            <label>Mobile </label>
            <input type="text" name="phone" class="form-control" placeholder="Enter Phone">

            <span class="text-danger Errphone"></span>
         </div>
         <div class="col-md-6">
            <label>State </label>
            <select name="state_id" class="form-control state_list_select">
               <option value="" selected="" disabled="">Select State</option>
               <?php $__currentLoopData = CustomHelper::getStates() ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <span class="text-danger Errstate_id"></span>
         </div>
         <div class="col-md-6">
            <label>City </label>
            <select name="city_id" class="form-control city_list"></select>
            <span class="text-danger Errcity_id"></span>
         </div>
         <div class="col-md-12">
            <label>Address </label>
            <textarea name="location" class="form-control" placeholder="Enter Location "></textarea>

            <span class="text-danger Errlocation"></span>
         </div>
      </div>
   </div>
   <div class="modal-footer">
      <?php if (isset($component)) { $__componentOriginal96198cdcbb817f0c0551bcabb1f17369 = $component; } ?>
<?php $component = App\View\Components\Backend\Proloader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.proloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Proloader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369)): ?>
<?php $component = $__componentOriginal96198cdcbb817f0c0551bcabb1f17369; ?>
<?php unset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369); ?>
<?php endif; ?>
      <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
   </div>
</form>
<?php echo $__env->make('frontend.layouts.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/pages/lead_inquiry_services.blade.php ENDPATH**/ ?>