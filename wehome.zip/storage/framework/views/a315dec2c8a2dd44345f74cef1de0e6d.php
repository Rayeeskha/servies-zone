<!--Features Section Satrt-->
<section id="features">
  <div class="container text-center features-section">
    <div class="row text-left">
      <div class="col-md-6 col-sm-6 col-xs-12 text-center"> <img src="<?php echo e(asset('frontend/images/qualit_work.png')); ?>"  alt="Meet the Hire Pros"/> </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <h2>Meet the Hire Pros</h2>
        <div class="icon_box_one"> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
          <div class="box_content">
            <h4>Lorem Ipsum is simply dummy text</h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
          </div>
        </div>
        <div class="icon_box_one"> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
          <div class="box_content">
            <h4>Lorem Ipsum is simply dummy text</h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
          </div>
        </div>
        <div class="icon_box_one"> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
          <div class="box_content">
            <h4>Lorem Ipsum is simply dummy text</h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's .</p>
          </div>
        </div>
        <div class="icon_box_one"> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
          <div class="box_content">
            <h4>Lorem Ipsum is simply dummy text</h4>
            <p>dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Features Section End--> <?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/layouts/include/feature.blade.php ENDPATH**/ ?>