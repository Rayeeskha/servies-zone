<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="content container-fluid">
  <div class="page-header">
	  <div class="page-title">
	    <h4>Role & Permissions</h4>
	    <h6>Manage Role & Permissions</h6>
	  </div>
    <?php if($addPermission): ?>
	    <div class="page-btn">
	      <a class="btn btn-added" href="<?php echo e(route('admin.role-master.create')); ?>"><img src="<?php echo e(asset('backend/assets/img/icons/plus.svg')); ?>" alt="img" class="me-1">Add Role Permission</a>
	    </div>
    <?php endif; ?>
	</div>
  <div class="row">
      <div class="col-sm-12">
         <div class="card">
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table  yajra-datatable">
                     <thead>
                        <tr>
                          <th>#</th>
                          <th>Role Name</th>
                          <th>Permission</th>
                          <th>Status</th>
                          <th>Created at</th>
                          <th>Action</th>
                        </tr>
                     </thead>
                     <tbody></tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
  </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<script type="text/javascript">
  $(function () {
    let table = $('.yajra-datatable').DataTable({
      processing: true,
      serverSide: true,
      ajax: "<?php echo e(route('admin.role-master.index')); ?>",
      columns: [
        {data: 'DT_RowIndex', orderable: false,searchable: false},
        {data: 'name', name: 'name'},
        {data: 'permissions', name: 'permissions'},
        {data: 'status', name: 'status'},
        {data: 'created_at', name: 'created_at'},
        {data: 'action',  name: 'action',  orderable: false,   searchable: false },
      ],
      createdRow: function( row, data, dataIndex ) {
        $(row).attr('row-id',data.id+'-role_masters');
      }
    });
  });
</script>	<?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/admin/role_master/index.blade.php ENDPATH**/ ?>