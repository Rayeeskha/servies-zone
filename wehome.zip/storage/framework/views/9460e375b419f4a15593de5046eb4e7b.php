<div>
    <section id="services">
	  <div class="container text-center">
	    <h1 class="panel-heading">Our services</h1>
	    <ul class="services-list">
	    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      <li><a href="<?php echo e(route('services', $service->slug)); ?>"><img src="<?php echo e(asset($service->image)); ?>" alt="<?php echo e($service->service_name); ?>" style="width: 100%; height: 100%; border: 1px solid silver" />
	      	<br /><?php echo e($service->service_name); ?></a></li>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    	     
	    </ul>
	  </div>
	</section>
</div><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/components/frontend/our-services.blade.php ENDPATH**/ ?>