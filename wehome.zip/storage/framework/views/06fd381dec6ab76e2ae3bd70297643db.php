<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="content">
      <div class="page-header">
         <div class="page-title">
            <h4>Profile</h4>
            <h6>User Profile</h6>
         </div>
      </div>
      <div class="card">
         <div class="card-body">
            <div class="profile-set">
               <div class="profile-head"></div>
               <div class="profile-top">
                  <div class="profile-content">
                     <div class="profile-contentimg">
                        <img src="<?php echo e(asset(session()->get('PROFILE_IMAGE') ? session()->get('PROFILE_IMAGE') : Auth::user()->profile)); ?>" alt="img" id="blah">
                        <div class="profileupload">
                           <input type="file" id="imgInp">
                           <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/edit-set.svg')); ?>" alt="img"></a>
                        </div>
                     </div>
                     <div class="profile-contentname">
                        <h2><?php echo e(Auth::user()->name); ?></h2>
                        <h4>Updates Your Photo and Personal Details.</h4>
                     </div>
                  </div>
                  <!-- <div class="ms-auto">
                     <a href="javascript:void(0);" class="btn btn-submit me-2">Save</a>
                     <a href="javascript:void(0);" class="btn btn-cancel">Cancel</a>
                     </div> -->
               </div>
            </div>
            <div class="row">
               <div class="col-lg-6">
                  <div class="rounded shadow mt-4">
                     <div class="p-4 border-bottom">
                        <h6 class="mb-0">Personal Information :</h6>
                     </div>
                     <div class="p-4">
                        <div class="row align-items-center">
                           <center>
                              <div class="col-lg-2 col-md-4">
                                 <img src="<?php echo e(asset(session()->get('PROFILE_IMAGE') ? session()->get('PROFILE_IMAGE') : Auth::user()->profile)); ?>" class="avatar avatar-md-md rounded-pill shadow mx-auto d-block" alt="">
                              </div>
                           </center>
                           <!--end col-->
                        </div>
                        <hr>
                        <!--end row-->
                        <form  action="<?php echo e(route('profile.update')); ?>"  
                           enctype="multipart/form-data" method="post" class="validateForm">  
                           <?php echo method_field('patch'); ?>                         
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="mb-3">
                                    <label class="form-label">First Name</label>
                                    <input name="name" id="first_name" type="text" class="form-control" placeholder="First Name :" value="<?php echo e(Auth::user()->name); ?>">
                                 </div>

                                 <span class="text-danger Errname"></span>
                              </div>
                              <div class="col-md-6">
                                 <div class="mb-3">
                                    <label class="form-label">Your Email</label>
                                    <input name="email"  type="email" class="form-control" placeholder="Your email :" value="<?php echo e(Auth::user()->email); ?>" readonly>
                                    <span class="text-danger Erremail"></span>
                                 </div>
                              </div>
                              <!--end col-->
                              <div class="col-md-6">
                                 <div class="mb-3">
                                    <label class="form-label">Phone no.</label>
                                    <input name="number" type="text" class="form-control" placeholder="Phone no. :" value="<?php echo e(Auth::user()->number); ?>">
                                    <span class="text-danger Errnumber"></span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="mb-3">
                                    <label class="form-label">profile</label>
                                    <input name="profile" type="file" class="form-control image" >
                                    <span class="text-danger Errprofile"></span>
                                 </div>
                                 <div class="preview_image_div" style="display: none;">
                                    <img src="" class="preview_image image_responsive" style="width: 50px;height: 50px; border-radius: 50%;">
                                 </div>
                                 <div class="image_show"></div>
                              </div>
                           </div>
                           <!--end row-->
                           <div class="row">
                              <div class="col-sm-12">

                                 <?php if (isset($component)) { $__componentOriginal96198cdcbb817f0c0551bcabb1f17369 = $component; } ?>
<?php $component = App\View\Components\Backend\Proloader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.proloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Proloader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369)): ?>
<?php $component = $__componentOriginal96198cdcbb817f0c0551bcabb1f17369; ?>
<?php unset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369); ?>
<?php endif; ?>

                                 <button type="submit" class="btn btn-primary " style="float: right;"><i class="fa fa-spinner fa-spin" style="display: none;"></i>&nbsp;Update</button>
                              </div>
                              <!--end col-->
                           </div>
                           <!--end row-->
                        </form>
                        <!--end form-->
                     </div>
                  </div>
               </div>
               <!--end col-->
               <div class="col-md-6">
                  <div class="rounded shadow mt-4">
                     <div class="p-4 border-bottom">
                        <h6 class="mb-0">Account Settings :</h6>
                     </div>
                     <div class="p-4">
                        <form method="post" action="<?php echo e(route('password.update')); ?>" class="validateForm2" >
                           <?php echo csrf_field(); ?>
                           <?php echo method_field('put'); ?>
                           <div class="row">
                              <div class="col-lg-12">
                                 <div class="form-group">
                                    <label>Current Password</label>
                                    <div class="pass-group">
                                       <input type="password" class="pass-input" name="current_password" autocomplete="current-password">
                                       <span class="fas toggle-password fa-eye-slash"></span>
                                    </div>
                                    <span class="text-danger Errcurrent_password"></span>
                                 </div>
                              </div>
                              <!--end col-->
                              <div class="col-lg-12">
                                 <div class="form-group">
                                    <label>New Password</label>
                                    <div class="pass-group">
                                       <input type="password" class="pass-input"  name="password" autocomplete="new-password" >
                                       <span class="fas toggle-password fa-eye-slash"></span>
                                    </div>
                                    <span class="text-danger Errpassword"></span>
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <div class="form-group">
                                    <label>Confirm Password</label>
                                    <div class="pass-group">
                                       <input type="password" class=" pass-input"  name="password_confirmation" autocomplete="new-password" >
                                       <span class="fas toggle-password fa-eye-slash"></span>
                                    </div>
                                    <span class="text-danger Errpassword_confirmation"></span>
                                 </div>
                              </div>
                              <!--end col-->
                              <div class="col-lg-12 mt-2 mb-0">
                                  <?php if (isset($component)) { $__componentOriginaleec75e88dfcfd01687b03ab2b305834a = $component; } ?>
<?php $component = App\View\Components\Backend\Proloader2::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.proloader2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Proloader2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec75e88dfcfd01687b03ab2b305834a)): ?>
<?php $component = $__componentOriginaleec75e88dfcfd01687b03ab2b305834a; ?>
<?php unset($__componentOriginaleec75e88dfcfd01687b03ab2b305834a); ?>
<?php endif; ?>
                                 <button type="submit" class="btn btn-primary " style="float: right;"><i class="fa fa-spinner fa-spin spinner" style="display: none;"></i>&nbsp;Update</button>
                              </div>
                              <!--end col-->
                           </div>
                           <!--end row-->
                        </form>
                     </div>
                  </div>
               </div>
               <!--end col-->
            </div>
         </div>
      </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/admin/profile/settings.blade.php ENDPATH**/ ?>