
<?php $__env->startSection('page_title','Wehome Services'); ?>
<?php $__env->startSection('meta_keywords','Wehome Services'); ?>
<?php $__env->startSection('meta_description', 'Wehome Services'); ?>
<?php $__env->startSection('container'); ?>

<!-- Slider -->
<?php if (isset($component)) { $__componentOriginal87ceddcbf94d2fab66dc139ed68704eb = $component; } ?>
<?php $component = App\View\Components\Frontend\Slider::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87ceddcbf94d2fab66dc139ed68704eb)): ?>
<?php $component = $__componentOriginal87ceddcbf94d2fab66dc139ed68704eb; ?>
<?php unset($__componentOriginal87ceddcbf94d2fab66dc139ed68704eb); ?>
<?php endif; ?>

<!-- How it works -->
<?php echo $__env->make('frontend.layouts.include.how_it_works', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Our Services -->
<?php if (isset($component)) { $__componentOriginal2e3143eab6f906a4ca58690aa2d6e66b = $component; } ?>
<?php $component = App\View\Components\Frontend\OurServices::resolve(['name' => 'services','services' => $services] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.our-services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\OurServices::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e3143eab6f906a4ca58690aa2d6e66b)): ?>
<?php $component = $__componentOriginal2e3143eab6f906a4ca58690aa2d6e66b; ?>
<?php unset($__componentOriginal2e3143eab6f906a4ca58690aa2d6e66b); ?>
<?php endif; ?>

<!-- Trust -->
<?php echo $__env->make('frontend.layouts.include.trust', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
<!-- Our Number -->
<?php echo $__env->make('frontend.layouts.include.our_number', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Feature -->
<?php echo $__env->make('frontend.layouts.include.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Testimonial -->
<?php if (isset($component)) { $__componentOriginal3b83051b9e38e4816ac2589a296b68cc = $component; } ?>
<?php $component = App\View\Components\Frontend\Testimonial::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Testimonial::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b83051b9e38e4816ac2589a296b68cc)): ?>
<?php $component = $__componentOriginal3b83051b9e38e4816ac2589a296b68cc; ?>
<?php unset($__componentOriginal3b83051b9e38e4816ac2589a296b68cc); ?>
<?php endif; ?>

<!-- Download App -->
<?php echo $__env->make('frontend.layouts.include.download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/index.blade.php ENDPATH**/ ?>