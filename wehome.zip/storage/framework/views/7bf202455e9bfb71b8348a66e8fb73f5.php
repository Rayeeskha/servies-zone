<?php if (isset($component)) { $__componentOriginala7154547718a3a476f0ee910c1d5abaf = $component; } ?>
<?php $component = App\View\Components\Backend\Css::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Css::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7154547718a3a476f0ee910c1d5abaf)): ?>
<?php $component = $__componentOriginala7154547718a3a476f0ee910c1d5abaf; ?>
<?php unset($__componentOriginala7154547718a3a476f0ee910c1d5abaf); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginald29d017063282db0b2391e16985f9338 = $component; } ?>
<?php $component = App\View\Components\Backend\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald29d017063282db0b2391e16985f9338)): ?>
<?php $component = $__componentOriginald29d017063282db0b2391e16985f9338; ?>
<?php unset($__componentOriginald29d017063282db0b2391e16985f9338); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal4acc4280d1e49d24ac528601997dc9c2 = $component; } ?>
<?php $component = App\View\Components\Backend\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4acc4280d1e49d24ac528601997dc9c2)): ?>
<?php $component = $__componentOriginal4acc4280d1e49d24ac528601997dc9c2; ?>
<?php unset($__componentOriginal4acc4280d1e49d24ac528601997dc9c2); ?>
<?php endif; ?>

<!-- Page Container START -->
<div class="page-wrapper">
    <?php echo e($slot); ?>

</div>


<?php if (isset($component)) { $__componentOriginala91a72c852c2cf0f5b9576c03744df43 = $component; } ?>
<?php $component = App\View\Components\Backend\Js::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Js::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala91a72c852c2cf0f5b9576c03744df43)): ?>
<?php $component = $__componentOriginala91a72c852c2cf0f5b9576c03744df43; ?>
<?php unset($__componentOriginala91a72c852c2cf0f5b9576c03744df43); ?>
<?php endif; ?>
<?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>