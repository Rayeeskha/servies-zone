<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="content">
      <div class="page-header">
         <div class="page-title">
            <h4>Employee Management</h4>
         </div>
         <div class="page-btn">
            <a class="btn btn-added" href="<?php echo e(route('admin.employee.index')); ?>"><span class="fa fa-share"></span>&nbsp;&nbsp;All Employees</a>
         </div>
      </div>
      <div class="card">
         <div class="card-body">
            <form class="validateForm" action="<?php echo e(route('admin.employee.store')); ?>" method="post" enctype="multipart/form-data">
               <input type="hidden" name="id" value="<?php echo e(@$user->id); ?>">
               <div class="row">
                  <div class="col-lg-4 col-sm-6 col-12">
                     <div class="form-group">
                        <label>User Name</label>
                        <input type="text" name="name" value="<?php echo e(@$user->name); ?>">
                        <span class="text-danger Errname"></span>
                     </div>
                     <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" value="<?php echo e(@$user->email); ?>">
                        <span class="text-danger Erremail"></span>
                     </div>
                     <div class="form-group">
                        <label>Password</label>
                        <div class="pass-group">
                           <input type="password" class=" pass-input" name="password">
                           <span class="fas toggle-password fa-eye-slash"></span>
                           <span class="text-danger Errpassword"></span>
                        </div>
                     </div>
                     <div class="form-group">
                        <label>Lead Services Permission</label>
                        <select class="select" name="lead_services_id[]" multiple="">
                           <option value="" selected="" disabled="">Select Lead Services</option>
                           <?php $__currentLoopData = CustomHelper::getBookingLeadService(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e(@$val->id); ?>" <?php echo e(in_array($val->id, explode(",",@$user->lead_services_id) ?: []) ? "selected": ""); ?>><?php echo e(@$val->service_name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger Errlead_service_id"></span>
                     </div>
                  </div>
                  <div class="col-lg-4 col-sm-6 col-12">
                     <div class="form-group">
                        <label>Mobile</label>
                        <input type="text" name="number" value="<?php echo e(@$user->number); ?>">
                        <span class="text-danger Errnumber"></span>
                     </div>
                     <div class="form-group">
                        <label>Role</label>
                        <select class="select" name="role_id">
                           <option value="" selected="" disabled="">Select Role</option>
                           <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e(@$role->id); ?>" <?php echo e(@$user->role_id == $role->id ? 'selected' : ''); ?>><?php echo e(@$role->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger Errrole_id"></span>
                     </div>
                     <div class="form-group">
                        <label>Confirm Password</label>
                        <div class="pass-group">
                           <input type="password" class=" pass-inputs" name="password_confirmation">
                           <span class="fas toggle-passworda fa-eye-slash"></span>
                        </div>
                        <span class="text-danger Errpassword_confirmation"></span>
                     </div>
                  </div>
                  <div class="col-lg-4 col-sm-6 col-12">
                     <div class="form-group">
                        <label> Profile Picture</label>
                        <div class="image-upload image-upload-new">
                           <input type="file" name="profile" class="image">
                           <div class="image-uploads">
                              <img src="<?php echo e(@$user->profile ? asset($user->profile) : asset('backend/assets/img/icons/upload.svg')); ?>" alt="img">
                              <h4>Drag and drop a file to upload</h4>
                           </div>
                        </div>
                        <div class="preview_image_div" style="display: none;">
                           <img src="" class="preview_image image_responsive" style="width: 50px;height: 50px; border-radius: 50%;">
                        </div>
                        <div class="image_show"></div>
                        <span class="text-danger Errprofile"></span>
                     </div>
                  </div>
                  <div class="col-lg-12">
                     <?php if (isset($component)) { $__componentOriginal96198cdcbb817f0c0551bcabb1f17369 = $component; } ?>
<?php $component = App\View\Components\Backend\Proloader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.proloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Proloader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369)): ?>
<?php $component = $__componentOriginal96198cdcbb817f0c0551bcabb1f17369; ?>
<?php unset($__componentOriginal96198cdcbb817f0c0551bcabb1f17369); ?>
<?php endif; ?>
                     <button type="submit" class="btn btn-submit me-2"><span class="fa fa-plus"></span>&nbsp;&nbsp;Submit</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/admin/employees/create.blade.php ENDPATH**/ ?>