<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<!-- <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>  -->
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('frontend/js/owlcarousel/owl.carousel.min.js')); ?>"></script> 
<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- Toaster Js Link -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<!-- Toaster Js Link -->
<script src="<?php echo e(asset('backend/assets/js/common/validation.js')); ?>"></script> 
<script src="<?php echo e(asset('backend/assets/js/common/validate.min.js')); ?>"></script> 

<script>let ajax = '<?php echo e(url('/')); ?>'</script>
<!-- Custom js -->
<script src="<?php echo e(asset('backend/assets/js/common/common_setup.js')); ?>"></script>
<!-- Frontend js -->
<script src="<?php echo e(asset('frontend/js/project.js')); ?>"></script>


</body>

</html><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/layouts/include/js.blade.php ENDPATH**/ ?>