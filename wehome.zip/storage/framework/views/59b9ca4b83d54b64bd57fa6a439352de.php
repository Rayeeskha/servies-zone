
<?php $__env->startSection('page_title','Wehome Services'); ?>
<?php $__env->startSection('meta_keywords','Wehome Services'); ?>
<?php $__env->startSection('meta_description', 'Wehome Services'); ?>
<?php $__env->startSection('container'); ?>

<!--Page Title Section Satrt-->
<div id="page_title">
<div class="container text-center">
  <div class="panel-heading">services</div>
  <ol class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li class="active">Services</li>
  </ol>
</div>
</div>
<!--Page Title Section End--> 

<!--Service Page Start-->
<section id="service_page">
  <div class="container text-center">
    <div class="row">
      <?php $__currentLoopData = $services ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 col-sm-6 col-xs-12 srevice_img"> <a href="<?php echo e(route('services', $service->slug)); ?>"><img src="<?php echo e(asset($service->image)); ?>" class="img-circle htw" alt="cleaning" /></a>
        <h4><a href="<?php echo e(route('services', $service->slug)); ?>"><?php echo e(@$service->service_name); ?></a></h4>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
  </div>
</section>
<!--Service Page End--> 

<!-- World Service Provider -->
<?php if (isset($component)) { $__componentOriginald50edad72927b4f1cecbab633c41f1d4 = $component; } ?>
<?php $component = App\View\Components\Frontend\WorldServiceProvider::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.world-service-provider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\WorldServiceProvider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald50edad72927b4f1cecbab633c41f1d4)): ?>
<?php $component = $__componentOriginald50edad72927b4f1cecbab633c41f1d4; ?>
<?php unset($__componentOriginald50edad72927b4f1cecbab633c41f1d4); ?>
<?php endif; ?>
<!--/Service Provider Satrt End--> 

<!-- Testimonial -->
<?php if (isset($component)) { $__componentOriginal3b83051b9e38e4816ac2589a296b68cc = $component; } ?>
<?php $component = App\View\Components\Frontend\Testimonial::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Testimonial::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b83051b9e38e4816ac2589a296b68cc)): ?>
<?php $component = $__componentOriginal3b83051b9e38e4816ac2589a296b68cc; ?>
<?php unset($__componentOriginal3b83051b9e38e4816ac2589a296b68cc); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/pages/static/services.blade.php ENDPATH**/ ?>