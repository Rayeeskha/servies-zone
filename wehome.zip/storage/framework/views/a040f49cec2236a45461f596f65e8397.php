<a href="/">
    <img src="<?php echo e(asset('backend/assets/images/logo/wehome_lg.png')); ?>" class="w-30 h-30 fill-current text-gray-500">
</a><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/components/logo.blade.php ENDPATH**/ ?>