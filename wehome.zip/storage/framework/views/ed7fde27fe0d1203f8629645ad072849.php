<div>
	    <!--Testimonails Section Satrt-->
	<section id="testimonails">
	  <div class="container text-center">
	    <h1 class="panel-heading">Testimonails</h1>
	    <div class="row">
	      <div class="col-md-12">
	        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel "> <!-- Indicators -->
	          <ol class="carousel-indicators">
	            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
	            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
	            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
	          </ol>
	          <!-- Wrapper for slides -->
	          <div class="carousel-inner text-center">
	            <div class="item active">
	              <div class="avatar"><img class="img-circle" src="<?php echo e(asset('frontend/images/clinte1.png')); ?>"   alt="Client 1"/></div>
	              <h3>Kevin Austin</h3>
	              <strong>Lorem Ipsum</strong>
	              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, a</p>
	            </div>
	            <div class="item">
	              <div class="avatar"><img class="img-circle" src="<?php echo e(asset('frontend/images/testimonails2.png')); ?>" alt="Client 2"></div>
	              <h3>Kevin Austin</h3>
	              <strong>Lorem Ipsum</strong>
	              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, a</p>
	            </div>
	            <div class="item">
	              <div class="avatar"><img class="img-circle" src="<?php echo e(asset('frontend/images/testimonails3.png')); ?>" alt="Client 3"></div>
	              <h3>Kevin Austin</h3>
	              <strong>Lorem Ipsum</strong>
	              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, a</p>
	            </div>
	          </div>
	          <!-- Controls --> <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> <span class="fa fa-angle-left"></span> </a> <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> <span class="fa fa-angle-right"></span> </a> </div>
	      </div>
	    </div>
	  </div>
	</section>
	<!--Testimonails Section End--> 
</div><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/components/frontend/testimonial.blade.php ENDPATH**/ ?>