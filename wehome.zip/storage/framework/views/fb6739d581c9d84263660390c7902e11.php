
<?php $__env->startSection('page_title','Wehome Aboutus'); ?>
<?php $__env->startSection('meta_keywords','Wehome Aboutus'); ?>
<?php $__env->startSection('meta_description', 'Wehome Aboutus'); ?>
<?php $__env->startSection('container'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\wehome\resources\views/frontend/pages/static/aboutus.blade.php ENDPATH**/ ?>