<?php 

namespace App\Traits;
use Auth;

trait BelongsTo{

	public function role(){
		return $this->belongsTo('App\Models\RoleMaster', 'role_id', 'id');
	}

	public function user(){
		return $this->belongsTo('App\Models\User', 'user_id', 'id');
	}

	
	public function scopePermission($query){
    	if (Auth::user()->role_id == 1) {
    		return $query;
    	}elseif (Auth::user()->role_id == 5) {            
            return $query->whereassign_electrician_id(Auth::user()->id);
        }else{
    		return $query->whereIn('lead_service_id', explode(',',Auth::user()->lead_services_id));
    	}
    }

    public function scopeLeadPermission($query){
        if (Auth::user()->role_id == 1) {
            return $query;
        }else{
            return $query->whereIn('id', explode(',',Auth::user()->lead_services_id));
        }
    }

    public function state(){
    	return $this->belongsTo('App\Models\State', 'state_id', 'id');
    }

    public function city(){
    	return $this->belongsTo('App\Models\City', 'city_id', 'id');
    }

    public function leadService(){
    	return $this->belongsTo('App\Models\LeadService', 'lead_service_id', 'id');
    }
	

	

}