function onClickHandlerModule(argument) {
  $("#" + argument+'_add').prop('checked', false);
  $("#" + argument+'_edit').prop('checked', false);
  $("#" + argument+'_delete').prop('checked', false);
}

function onClickHandler(argument) {
  var withoutLastChunk = argument.slice(0, argument.lastIndexOf("_"));
  $("#" + withoutLastChunk).prop('checked', true);
}

function feedBackModal(id, slug){
  let title = "Electrician Feedback";
  if (slug == "employee") {
    title = "Employee Feedback";
  }
  $('.modal-title').html(title);
  $('.lead_inquiry_id').val(id);
  $('.lead_inquiry_type').val(slug);
  $('.feedBackModal').modal('show');
}

// State List
$(document).ready(function(){
    $('.state_list_select').change(function(){      
      var id=$(this).val();
      $.ajax({
        type:"GET",
        url:ajax+'/get-cities/'+id,
        async : true,
        dataType : 'json',
        success: function(response){
          let resultData = response.cities;
          let option = '';
          $.each(resultData,function(index,row){
            option+= '<option value='+row.id+'>'+row.districts_name+'</option>';
            $('.city_list').html(option); 
          });
        }
      });
    }); 
});